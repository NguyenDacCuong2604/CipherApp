package RunApp;

import GUI.HomeGUI;

public class Main {
    public static void main(String... args) {
        HomeGUI gui = new HomeGUI();
    }
}
